const VerificationType = {
    OTP: "otp",
    EMAIL: "email"
}

export default VerificationType;
