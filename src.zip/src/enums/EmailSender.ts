const EmailSender = {
    NO_REPLY: "noreply@unox.one"
}

export default EmailSender;