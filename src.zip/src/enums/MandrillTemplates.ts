const MailTemplates = {
    OTP: "verification-otp",
    RESET_PASSWORD: "reset-password"
}

export default MailTemplates;
