const LoginType = {
    PASSWORD: "password",
    GOOGLE: "google"
}

export default LoginType;
