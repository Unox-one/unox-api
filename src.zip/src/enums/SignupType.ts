const SignupType = {
    PASSWORD: "password",
    GOOGLE: "google"
}

export default SignupType;
